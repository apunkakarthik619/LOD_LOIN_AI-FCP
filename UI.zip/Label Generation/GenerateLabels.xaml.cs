﻿using Autodesk.Revit.UI;
using Autodesk.Revit.DB;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Python.Runtime;
using System.IO;

namespace ZiguratAI.Views.UI
{
    /// <summary>
    /// Interaction logic for GenerateLabels.xaml
    /// </summary>
    public partial class GenerateLabels : Window
    {
        public UIDocument uidoc { get; }
        public UIApplication uiapp { get; }
        public Document doc { get; }

        string RulesPath = "";
        string scriptPath = "";
        string location = "";
        public GenerateLabels(UIDocument UiDoc, UIApplication uiapp)
        {
            InitializeComponent();
            uidoc = UiDoc;
            doc = UiDoc.Document;
        }
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            DragMove();
        }

        private void Closebtn(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void txtbtn(object sender, RoutedEventArgs e)
        {

        }
        private void updatebtn(object sender, RoutedEventArgs e)
        {

            string outCsv = location;

            string rulesPath = RulesPath;

            using (Py.GIL())
            {
                dynamic sys = Py.Import("sys");
                dynamic io = Py.Import("io");
                var output = io.StringIO();
                sys.stdout = output;
                sys.stderr = output;

                using (var globals = new PyDict())
                {
                    globals.SetItem("__revit__", uiapp.ToPython());   // pyRevit-style
                    globals.SetItem("UIAPP", uiapp.ToPython());       // optional alias
                    globals.SetItem("UIDOC", uidoc.ToPython());
                    globals.SetItem("DOC", doc.ToPython());

                    // IMPORTANT: match the names your Python expects
                    globals.SetItem("OUT_PATH", new PyString(outCsv));
                    globals.SetItem("RULES_PATH", new PyString(rulesPath));

                    try
                    {
                        string code = File.ReadAllText(scriptPath);   // your existing script path is fine
                        PythonEngine.Exec(code, globals, null);
                    }
                    catch (PythonException ex)
                    {
                        TaskDialog.Show("Python Error", ex.Message + "\n\n" + ex.StackTrace);
                    }
                }

                var prints = output.getvalue().ToString();
                if (!string.IsNullOrWhiteSpace(prints))
                    TaskDialog.Show("Python Output", prints);
            }

            // Optionally open CSV (use full path, not just file name)
            if (File.Exists(outCsv))
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = outCsv,           // <- full path so it opens reliably
                    UseShellExecute = true
                });
                this.Close();
            }
        }
        private void rules_btn(object sender, RoutedEventArgs e)
        {
            RulesPath = Classes.Files.SelectFolder();
            string fileName = System.IO.Path.GetFileName(RulesPath);

            if (RulesPath != string.Empty)
            {
                rules_name.Text = fileName;
                rules_name.FontSize = 10;
                SolidColorBrush blueBrush = new SolidColorBrush(Colors.DarkGray);
                rules_name.Foreground = blueBrush;
            }
            if (RulesPath != "")
            {

            }
        }

        private void Script_btn(object sender, RoutedEventArgs e)
        {
            scriptPath = Classes.Files.OpenFile();
            string fileName = System.IO.Path.GetFileName(scriptPath);

            if (scriptPath != string.Empty)
            {
                script_name.Text = fileName;
                script_name.FontSize = 10;
                SolidColorBrush blueBrush = new SolidColorBrush(Colors.DarkGray);
                script_name.Foreground = blueBrush;
            }
            if (scriptPath != "")
            {

            }
        }

        private void location_btn(object sender, RoutedEventArgs e)
        {


            string loc = Classes.Files.SelectFolder();
            string fileName = "params_export.csv";
            location = System.IO.Path.Combine(loc, fileName);

            if (location != string.Empty)
            {
                location_name.Text = fileName;
                location_name.FontSize = 10;
                SolidColorBrush blueBrush = new SolidColorBrush(Colors.DarkGray);
                location_name.Foreground = blueBrush;
            }
            if (location != "")
            {

            }
        }
    }


}