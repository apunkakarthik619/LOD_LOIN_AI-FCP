﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Python.Runtime;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ZiguratAI.Views.UI
{
    /// <summary>
    /// Interaction logic for ExportGeo.xaml
    /// </summary>
    public partial class ExportGeo : Window
    {
        public UIDocument uidoc { get; }
        public UIApplication uiapp { get; }
        public Document doc { get; }
        string scriptPath = "";
        string location = "";

        public ExportGeo(UIDocument UiDoc, UIApplication uiapp)
        {
            InitializeComponent();
            uidoc = UiDoc;
            doc = UiDoc.Document;
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            DragMove();
        }

        private void Closebtn(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void txtbtn(object sender, RoutedEventArgs e)
        {

        }
        private void updatebtn(object sender, RoutedEventArgs e)
        {
            //غيريها تاني
            //string outCsv = location;
            string outCsv = @"D:\\07-Zigurat\\Temp test";


     

            using (Py.GIL())
            {
                dynamic sys = Py.Import("sys");
                dynamic io = Py.Import("io");
                var output = io.StringIO();
                sys.stdout = output;
                sys.stderr = output;

                using (var globals = new PyDict())
                {
                    globals.SetItem("__revit__", uiapp.ToPython());   // pyRevit-style
                    globals.SetItem("UIAPP", uiapp.ToPython());       // optional alias
                    globals.SetItem("UIDOC", uidoc.ToPython());
                    globals.SetItem("DOC", doc.ToPython());

                    // IMPORTANT: match the names your Python expects
                    globals.SetItem("OUT_PATH", new PyString(outCsv));

                    try
                    {
                        //غيريها
                        string code = File.ReadAllText(@"D:\\07-Zigurat\\Temp test\\Geometry_Export.py");   // your existing script path is fine
                        //string code = File.ReadAllText(scriptPath);   // your existing script path is fine
                        PythonEngine.Exec(code, globals, null);
                    }
                    catch (PythonException ex)
                    {
                        TaskDialog.Show("Python Error", ex.Message + "\n\n" + ex.StackTrace);
                    }
                }

                var prints = output.getvalue().ToString();
                if (!string.IsNullOrWhiteSpace(prints))
                    TaskDialog.Show("Python Output", prints);
            }

            // Optionally open CSV (use full path, not just file name)
            if (File.Exists(outCsv))
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = outCsv,           // <- full path so it opens reliably
                    UseShellExecute = true
                });
                this.Close();
            }
        }
       

        private void Script_btn(object sender, RoutedEventArgs e)
        {
            scriptPath = Classes.Files.OpenFile();
            string fileName = System.IO.Path.GetFileName(scriptPath);

            if (scriptPath != string.Empty)
            {
                script_name.Text = fileName;
                script_name.FontSize = 10;
                SolidColorBrush blueBrush = new SolidColorBrush(Colors.DarkGray);
                script_name.Foreground = blueBrush;
            }
            if (scriptPath != "")
            {

            }
        }

        private void location_btn(object sender, RoutedEventArgs e)
        {


            string loc = Classes.Files.SelectFolder();
            string fileName = "geom_export.csv";
            location = System.IO.Path.Combine(loc, fileName);

            if (location != string.Empty)
            {
                location_name.Text = fileName;
                location_name.FontSize = 10;
                SolidColorBrush blueBrush = new SolidColorBrush(Colors.DarkGray);
                location_name.Foreground = blueBrush;
            }
            if (location != "")
            {

            }
        }
    }
    public static class PyExtensions
    {
        public static PyObject ToPython(this object obj)
        {
            return PyObject.FromManagedObject(obj);
        }
    }
    public static class PythonHost
    {
        private static bool initialized = false;

        public static void EnsureInitialized(string pythonDllPath)
        {
            if (!initialized)
            {
                Runtime.PythonDLL = pythonDllPath;
                PythonEngine.Initialize();
                initialized = true;
            }
        }
    }
    public static class PyHost
    {
        private static bool _initialized;
        private static readonly System.Reflection.Assembly _pyRuntimeAsm =
            typeof(Python.Runtime.PythonEngine).Assembly; // the one your project references

        static PyHost()
        {
            AppDomain.CurrentDomain.AssemblyResolve += (s, e) =>
            {
                var req = new System.Reflection.AssemblyName(e.Name);
                if (req.Name == "Python.Runtime") return _pyRuntimeAsm;
                return null;
            };
        }

        public static void EnsureInitialized(string pythonDllFullPath)
        {
            if (_initialized) return;
            if (!Python.Runtime.PythonEngine.IsInitialized)
            {
                Python.Runtime.Runtime.PythonDLL = pythonDllFullPath; // set BEFORE Initialize
                Python.Runtime.PythonEngine.Initialize();
            }
            _initialized = true;
        }
    }
}